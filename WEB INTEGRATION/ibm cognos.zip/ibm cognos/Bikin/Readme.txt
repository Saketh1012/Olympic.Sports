Thanks for downloading this template!

Template Name: Bikin
Template URL: https://bootstrapmade.com/bikin-free-simple-landing-page-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
